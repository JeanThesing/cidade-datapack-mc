# Executa um ciclo completo de verificação
execute if score @s moeda_temp_deposito matches 81.. run function banco:depositar/remover_itens/check_if_block

execute unless score @s moeda_temp_deposito matches 81.. if score @s moeda_temp_deposito matches 9.. run function banco:depositar/remover_itens/check_if_ingot

execute unless score @s moeda_temp_deposito matches 9.. if score @s moeda_temp_deposito matches 1.. run function banco:depositar/remover_itens/check_if_nugget

# Verifica se ainda precisa processar mais moedas
#execute if score @s moeda_temp_deposito matches 1.. run function banco:depositar/loop_deposito