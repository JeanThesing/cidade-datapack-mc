# banco:depositar/remover_itens/check_if_nugget
execute store result score @s item_temp run clear @s minecraft:gold_nugget 0
execute if score @s item_temp matches 1.. run function banco:depositar/remover_itens/clear_nuggets

# Se nao tem nuggets mas tem barra, quebra a barra em 9 nuggets
execute unless score @s item_temp matches 1.. run execute store result score @s item_temp run clear @s minecraft:gold_ingot 0
execute if score @s item_temp matches 1.. run function banco:depositar/remover_itens/convert_ingot

scoreboard players set @s item_temp 0
