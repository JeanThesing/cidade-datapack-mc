# Tarcila cozinha
tp @e[type=villager,name="Tarcila",limit=1] 59665.82 74.00 7912.50

# ronaldo do caldo dormir
tp @e[type=minecraft:villager,limit=1,name="Ronaldo do Caldo"] 59690 79 7938

#stephen hawking na cadeira
tp @e[type=minecraft:villager,name="Stephen Hawking",limit=1] 59740.51 68.50 7852.60
setblock 59736 64 7849 redstone_wire replace

#Cebolacio filmar conchas
tp @e[type=minecraft:villager,name="Cebolácio",limit=1] 59651.01 76.00 7904.09

