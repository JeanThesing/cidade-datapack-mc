# Dia:
execute if predicate dialogo:6h00-18h30 as @e[type=villager,tag=talk,tag=morador,name="Agente Danúbio",scores={talk=1..}] run scoreboard players set @s talk 1

execute if predicate dialogo:6h00-18h30 as @e[type=villager,tag=talk,tag=morador,name="Agente Danúbio",scores={talk=1}] at @s run function dialogo:npc/praia/danubio/danubio_dia

# Espião:
execute if predicate dialogo:18h30-5h30 as @e[type=villager,tag=talk,tag=morador,name="Agente Danúbio",scores={talk=1..}] run scoreboard players set @s talk 1

execute if predicate dialogo:18h30-5h30 as @e[type=villager,tag=talk,tag=morador,name="Agente Danúbio",scores={talk=1}] at @s run function dialogo:npc/praia/danubio/danubio_espiao