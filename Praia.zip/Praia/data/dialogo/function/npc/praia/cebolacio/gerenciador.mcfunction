# CEBOLÁCIO
# ========================================
# Noite:
execute if predicate dialogo:18h30-23h30 as @e[type=villager,tag=talk,tag=morador,name="Cebolácio",scores={talk=1..}] run scoreboard players set @s talk 1

execute if predicate dialogo:18h30-23h30 as @e[type=villager,tag=talk,tag=morador,name="Cebolácio",scores={talk=1}] at @s run function dialogo:npc/praia/cebolacio/cebolacio_noite