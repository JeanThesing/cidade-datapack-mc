# checa quando clica no villager
scoreboard players set @e[type=villager,tag=talk,tag=porta_capela,name="porta_capela",scores={talk=1..}] talk 1 
execute if entity @e[type=villager, tag=talk, tag=porta_capela, name="porta_capela", scores={talk=1..}] run function dialogo:npc/praia/porta_capelinha/porta

# execute if score @e[type=villager,name="porta_capela", tag=porta_capela, limit=1] porta_capela matches 1 run execute if entity @a[x=59590,y=71,z=8098] run function dialogo:npc/praia/porta_capelinha/abrir

