# Verifica se há evento de coração ativo (para dia)
    execute if predicate dialogo:12h00-18h30 as @a[distance=..10] unless score @s evento_coracao matches 1.. run function dialogo:npc/praia/seu_ivanir/evento_coracao/evento_coracao
# Caso não haja evento ativo, decide o diálogo padrão conforme a faixa de afeto (praça)
    execute if predicate dialogo:12h00-18h30 as @a[distance=..10] if score @s evento_coracao matches 1.. run function dialogo:npc/praia/seu_ivanir/faixa/select_faixa
# Caso não haja evento ativo, decide o diálogo padrão conforme a faixa de afeto (noite)
    execute if predicate dialogo:18h30-23h30 as @a[distance=..10] if score @s evento_coracao matches 1.. run function dialogo:npc/praia/seu_ivanir/seu_ivanir_noite


tag @e[type=villager,tag=talk,name="Seu Ivanir"] remove talk

