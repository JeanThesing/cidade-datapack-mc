execute at @e[type=villager,name="Telefone",tag=telefone, limit=1] run execute as @a[distance=..3] run function dialogo:npc/praia/telefone/check_moeda

tag @e[type=villager,tag=talk,name="Telefone"] remove talk
