# checa quando clica no villager
scoreboard players set @e[type=villager,tag=talk,tag=telefone,name="Telefone",scores={talk=1..}] talk 1 
execute if entity @e[type=villager, tag=talk, tag=telefone, name="Telefone", scores={talk=1..}] run function dialogo:npc/praia/telefone/telefone




