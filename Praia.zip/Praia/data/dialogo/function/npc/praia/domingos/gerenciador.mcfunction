# Dia
execute if predicate dialogo:6h00-18h30 run scoreboard players set @e[type=villager,tag=talk,tag=morador,name="Domingos Rodrigues",scores={talk=1..}] talk 1 
execute if predicate dialogo:6h00-18h30 if entity @e[type=villager, tag=talk, tag=morador, name="Domingos Rodrigues", scores={talk=1..}] run function dialogo:npc/praia/domingos/domingos_dia

