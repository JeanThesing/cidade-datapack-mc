scoreboard players set @a banco 0
scoreboard players set @a deposito 0
scoreboard players set @a deposito_possivel 0
scoreboard players set @a deposito_possivel_atual 0
scoreboard players set @a saque 0
scoreboard players set @a saque_temp 0
scoreboard players set @a moeda_temp 0
scoreboard players set @a moeda_temp_deposito 0
scoreboard players set @a temp_success 0






