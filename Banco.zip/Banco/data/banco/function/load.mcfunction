scoreboard objectives add banco dummy

scoreboard objectives add deposito_possivel dummy
scoreboard objectives add deposito_possivel_atual dummy
scoreboard objectives add deposito dummy
scoreboard objectives add deposito_temp dummy
scoreboard objectives add saque dummy
scoreboard objectives add moeda_temp dummy
scoreboard objectives add moeda_temp_deposito dummy
scoreboard objectives add saque_temp dummy
scoreboard objectives add temp_success dummy

scoreboard objectives add item_temp dummy
scoreboard objectives add deposito_block dummy
scoreboard objectives add deposito_ingot dummy
scoreboard objectives add deposito_nugget dummy



# CONSTANTES

scoreboard objectives add const_9 dummy
scoreboard players set const const_9 9 
scoreboard objectives add const_81 dummy
scoreboard players set const const_81 81 
scoreboard objectives add const_juros dummy
scoreboard players set const const_juros 3

scoreboard objectives add porcento dummy
scoreboard players set const porcento 100

scoreboard objectives add pormil dummy
scoreboard players set const pormil 1000

scoreboard objectives add juros dummy
scoreboard players set @a juros 0

scoreboard objectives add divida dummy
scoreboard objectives add divida_temp dummy



