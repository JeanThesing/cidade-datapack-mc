tellraw @s [{"text":"💰 Seu saldo é: ","color":"gold"},{"score":{"name":"@s","objective":"banco"}, "color":"aqua"}, {"text":" mango(s)", "color":"gold"}]


