# SACAR
execute as @a[scores={moeda_temp=1..}] run function banco:sacar/loop_sacar

#DEPOSITO
execute as @a[scores={moeda_temp_deposito=1..}] run function banco:depositar/loop_deposito

# REINICIALIZACOES DIARIAS, RENDIMENTOS E JUROS
execute if predicate banco:23h30 run function banco:processos_diarios/reseta_temp
# SALDO NEGATIVO -> DIVIDA
# execute as @a if score @s banco matches ..-1 run add_divida

