tellraw @s [{"text":"💰 Sua dívida atual é: ","color":"red"},{"score":{"name":"@s","objective":"moeda_temp_deposito"}, "color":"#e18a27"}, {"text":" moeda(s)", "color":"red"}]
