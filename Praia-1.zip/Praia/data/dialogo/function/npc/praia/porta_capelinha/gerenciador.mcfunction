execute as @e[type=villager,tag=morador,name="porta_capela"] run function dialogo:npc/praia/porta_capelinha/porta



