tellraw @a[distance=..8] [{"color":"gold","text":"<Gerusa> "},{"color":"white","text":"Finalmente posso dar uma descansada, meu trabalho é muito entediante..."}]

