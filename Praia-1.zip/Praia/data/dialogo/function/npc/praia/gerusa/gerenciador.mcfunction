# Gerusa Trabalho
execute if predicate dialogo:8h00-18h30 at @e[type=villager,tag=morador,name="Gerusa"] run function dialogo:npc/praia/gerusa/gerusa_trabalho
# Gerusa Noite
execute if predicate dialogo:18h30-23h30 at @e[type=villager,tag=morador,name="Gerusa"] run function dialogo:npc/praia/gerusa/gerusa_noite