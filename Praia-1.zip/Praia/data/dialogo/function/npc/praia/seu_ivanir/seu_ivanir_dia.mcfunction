# Dialogo padrão (sem eventos)
execute as @a[distance=..10] if score @s evento_coracao matches 1.. run tellraw @a[distance=..8] [{"color":"gold","text":"<Seu Ivanir>"},{"color":"white","text":" Boa tarde, meu jovem, o dia está lindo, não está?"}]
# Dialogo de 0 coracoes
execute as @a[distance=..10] unless score @s evento_coracao matches 1.. unless score @s afeto_seu_ivanir matches 1.. run function dialogo:npc/praia/seu_ivanir/praca_1/praca_trigger


tag @e[type=villager,tag=talk,name="Seu Ivanir"] remove talk

