tellraw @s [{"bold":true,"color":"white","text":"(Você dirige-se à casa de Seu Ivanir e toma um café com ele. Durante este tempo vocês conversam bastante, Seu Ivanir compartilha diversas anedotas e contos de sua vida. No final da noite você e o simpático senhor apanham um violão e cantam diversas sonâncias da velha guarda brasileira. Após isso vocês se despedem e você sai da humilde residência de Seu Ivanir.) "}]

tellraw @s [  "",  {"text":"✨ Você sente seu vínculo com ","color":"yellow"},  {"text":"Seu Ivanir","color":"gold","bold":true},  {"text":" fortalecer... \n","color":"yellow"},   {"text":"❤ +1 Coração ","color":"red"},  {"text":"(Progresso: ","color":"gray"},  {"score":{"name":"@s","objective":"afeto_seu_ivanir"},"color":"green"},  {"text":"/10)","color":"gray"}]

