# execute store result score encontroRandom random 3h00 run random roll 1..100
